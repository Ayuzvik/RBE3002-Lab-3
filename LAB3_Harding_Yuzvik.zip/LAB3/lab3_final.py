import rospy, tf, numpy, math, sys
#from kobuki_msgs.msg import BumperEvent
from std_msgs.msg import String
from geometry_msgs.msg import Twist, Pose, Point
from nav_msgs.msg import Odometry, OccupancyGrid
from geometry_msgs.msg import PoseStamped, PoseWithCovarianceStamped
#from tf.transformations import euler_from_quaternion
from nav_msgs.msg import GridCells

from Queue import PriorityQueue
from math import sqrt
 
xAdjust = 0.5
yAdjust = 0.5
def mapCallBack(data):
    global mapData
    global width
    global height
    global mapgrid
    global resolution
    global offsetX
    global offsetY

    mapgrid = data
    resolution = data.info.resolution
    mapData = data.data
    width = data.info.width
    height = data.info.height
    offsetX = data.info.origin.position.x
    offsetY = data.info.origin.position.y
    # publishCells(mapgrid)
    # printMapData(mapData, width, height)

    #print data.info
#___________________________________________________


def parseMapData(data, width, height):
    myMap = []
    row = 0
    for i in range(len(data)):
        if i % width == 0:
            row += 1
            print "" # newline after full row
        sys.stdout.write('%4s' %(data[i]))
        



def publishCells(info, publisher):
    print "publishing"

    # resolution and offset of the map
    a=0
    cells = GridCells()
    cells.header.frame_id = 'map'
    cells.cell_width = resolution 
    cells.cell_height = resolution
    
    for node in info:
        point = nodeToPoint(node)
        cells.cells.append(point)
    #pub.publish(cells)
    publisher.publish(cells)

def convertToGridCell(xClick, yClick):
    return int(((xClick - offsetX) - xAdjust * resolution) / resolution), int(((yClick - offsetY) - yAdjust * resolution) / resolution)

#Gives nodes out of clicked point
def nodeToPoint(node):
    point = Point()
    point.x = (node.x * resolution) + (xAdjust * resolution) + offsetX
    point.y = (node.y * resolution) + (yAdjust * resolution) + offsetY
    return point

#converts node to point
def convertInitNode(pose):
    global init_x_cord
    global init_y_cord
    print "converting node"    
    init_x_cord, init_y_cord = convertToGridCell(pose.pose.pose.position.x , pose.pose.pose.position.y)
    print "xStart: ", init_x_cord, "   yStart:", init_y_cord

#final node conversion
def convertFinalNode(pose):
    global final_x_cord
    global final_y_cordfinal_
    final_x_cord, final_y_cord = convertToGridCell(pose.pose.position.x, pose.pose.position.y)
    endNode = Node(None, final_x_cord, final_y_cord, 0)
    runAStar(Node(None, init_x_cord, init_y_cord, 1), endNode)
    print endNode

#node class to handle grid cells
# cost is 1 if space is free, 1000000 if space contains an obstacle
class Node():
 
    def __init__(self, parent, x, y, cost):
        self.parent = parent
        self.x = x
        self.y = y
        self.cost = cost
 
    def __str__(self):
        return "(" + str(self.x) + "," +  str(self.y) + ") cost: " + str(self.cost)
 
    def __eq__(self, other):
        if isinstance(other, self.__class__):
            return self.x == other.x and self.y == other.y
        else :
            return False
 
# run AStar takes in the starting node and the goal node
# it returns the optimal path between the two
def runAStar(startNode, goalNode):
    global closedSet
    global openSet
    closedSet = []
    openSet = []
    path = []
    wayPoints = []
    aStar(startNode, goalNode, path, closedSet, openSet, wayPoints)
    return path, wayPoints
 
# aStar algorithm
def aStar(startNode, goalNode, path, closedSet, openSet, wayPoints):
    global pub_closed
    print "Adding ", startNode, "to openSet"
    print "Start: ", startNode, "    Goal: ", goalNode
    openSet.append(startNode)
    while len(openSet) != 0:
        # rospy.sleep(0.005)
        # publishAStar()
        # get the end of the current best path and add it to the closed set

        # sort the open set to get the lowest valued node
        openSet = list(sorted(openSet, key=lambda x: totalCost(x, goalNode)))
        currentNode = openSet[0]
        openSet.remove(currentNode)
        closedSet.append(currentNode)
 
        print "Expanding ", currentNode
        # check if the current node is the goal
        if currentNode == goalNode:
            print "Reached: ", currentNode, "  Goal: ", goalNode, "   Start: ", startNode
            path = pathTrace(currentNode, path, wayPoints)
            publishCells(path, pub_path)
            #publishCells(wayPoints, way)
            break
 
        # build a set of the neighbors of the current grid cell
        children = getNeighbors(currentNode)
 
        # for each of the next nodes, either put it into the open set
        # using its cost as a priority or ignore it if it is in the closed set
        for child in children:
            if child not in closedSet and child not in openSet:               
                print "Adding ", child, "to openSet"
                openSet.append(child)

            elif child in closedSet:
                childIndex = closedSet.index(child)
                print "comparing child cost: ", child.cost, " to previous cost: ", closedSet[childIndex].cost
                if closedSet[childIndex].cost > child.cost:
                    print "Adding ", child, " to open set for being shorter than before"
                    openSet.append[child] 
                else:                     
                    print "Ignoring ", child, " (it is already in the closedSet)"

            elif child in openSet:
                childIndex = openSet.index(child)
                print "comparing child cost: ", child.cost, " to previous cost: ", openSet[childIndex].cost
                if openSet[childIndex].cost > child.cost:
                    openSet.append(child)
                    print "Adding ", child, "to openSet, faster than", openSet[openSet.index(child)].parent
                else:
                    print "Ignoring", child, ", no improvement"

            else:
                print "Ignoring", child, " (it is further to get here)"
        #publishing cells here
        publishCells(closedSet, pub_closed)
        publishCells(openSet, pub_open)

        # dummy = raw_input("Press Enter to continue...")
 
# can add "turning cost"
def totalCost(node, goalNode):
    return node.cost + heuristicValue(node, goalNode)
 
# this functions returns the heuristic value of the node
# at the moment it returns zero, which makes the algorithm
# behave like greedy search
def heuristicValue(node, goalNode):
    return sqrt(pow(goalNode.x - node.x, 2) + pow(goalNode.y - node.y, 2))
 
# pathtrace shows the path found by the algorithm
def pathTrace(node, path, wayPoints):
    path.append(node)
    publishCells(path, pub_path)
    publishCells(wayPoints, way_pub)
    rospy.sleep(0.05)
    while node.parent is not None:
    	#create waypoints 
    	if(node.parent.parent.x != node.x and node.parent.parent.y != node.y):
    print node
    return path, wayPoints
   
 
# returns the neighbors of this node
# will need to add check for free/obstacle
def getNeighbors(node):
    neighbors = []
    for dx in [-1,0, 1]:
        for dy in [-1,0,1]:
            # check edge of map conditions
            if node.x <= -width/2 and dx == -1:
                pass
            if node.x >= width/2 and dx == 1:
                pass
            if node.y <= -height/2 and dy ==-1:
                pass
            if node.y >= height/2 and dy == 1:
                pass
            
            if not (dx == 0 and dy == 0):
                # print "IS this an obstacle", mapData[int((node.y+dy) * width + (node.x+dx))]
                if mapData[int((node.y+dy) * width + (node.x+dx))] < 50:
                    if not ( abs(dx) == 1 and abs(dy) == 1):
                        # child = Node(node, node.x + dx, node.y +dy, node.cost+1)
                        neighbors.append(Node(node, node.x + dx, node.y +dy, node.cost+1))
                    #else : 
                        #neighbors.append(Node(node, node.x + dx, node.y +dy, node.cost+sqrt(2)))
    return neighbors


def run():
    global pub_open
    global pub_closed
    global pub_path
    global way_pub

    global mapData
    global width
    global height
    global mapgrid
    global resolution
    global offsetX
    global offsetY
       
    rospy.init_node('lab3')
   
    #gridCellsDet is a topic for sending data. Can rename it to whatever we want
    pub_open = rospy.Publisher("/openCells", GridCells, queue_size=1) 
    pub_closed = rospy.Publisher("/closedCells", GridCells, queue_size=1) 
    pub_path = rospy.Publisher("/pathCells", GridCells, queue_size=1) 
    way_pub = rospy.Publisher("/wayPoints", GridCells, queue_size=1) 

    sub = rospy.Subscriber("/map", OccupancyGrid, mapCallBack)
    sub_initPose = rospy.Subscriber('/initialpose1', PoseWithCovarianceStamped, convertInitNode, queue_size=10)   #initail pose 1 
    sub_finalPose = rospy.Subscriber('/move_base_simple/goal1', PoseStamped, convertFinalNode, queue_size=10) #goal 1 - need that to avoid Rviz running built in stuff
    rospy.sleep(10)



    while (1 and not rospy.is_shutdown()):
       # publishCells(mapData) 
        rospy.sleep(2)  
        # print("Complete")


if __name__ == '__main__':
    try:
        run()
    except rospy.ROSInterruptException:
        pass


